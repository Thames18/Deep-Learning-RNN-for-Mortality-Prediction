USE_CUDA = True  # Set 'True' if you want to use GPU
NUM_WORKERS = 0 